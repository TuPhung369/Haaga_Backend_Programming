package com.database.parttwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
